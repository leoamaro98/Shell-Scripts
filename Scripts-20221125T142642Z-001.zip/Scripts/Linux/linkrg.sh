#!/bin/bash
#wqvlc /opt/video2.mp4
#DISPLAY=:0 /usr/bin/chromium-browser --kiosk https://www.youtube.com/embed/g5VtuzqKlwU?autoplay=1
DISPLAY=:0 eog -f /opt/boaleo.png 


